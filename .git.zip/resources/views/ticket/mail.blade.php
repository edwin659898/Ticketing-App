<html>
<body>
Email
<p>{{$title}}</p>
<p>{{$content}}</p>
</body>
</html>
