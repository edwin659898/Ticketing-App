<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class step extends Model
{
  protected $fillable = ['step','todo_id',];
}
